# Galaxy S25 TTS precision comparison

One physical Galaxy S25 (SM-S931U1, Android 15), one warm request at a time.
Every engine received the same four English prompts split into the same three sentences. All workers used two inference threads and immediate AudioTrack playback.

| Configuration | Requests timed | First PCM p95 | First speech p95 | Synthesis p95 | Median RTF | Underrun requests | Retained audio |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| Kokoro-82M FP32 | 32 | 6797.1 ms | 7076.6 ms | 14119.4 ms | 1.818 | 32/32 | 1.0% WER · 2.83 predicted MOS |
| Kokoro-82M INT8 MatMul / FP32 | 32 | 6731.6 ms | 7017.4 ms | 14010.3 ms | 1.807 | 32/32 | 1.0% WER · 2.83 predicted MOS |
| Mini FP32 | 32 | 6066.4 ms | 6662.5 ms | 13013.7 ms | 1.279 | 27/32 | 0.0% WER · 2.82 predicted MOS |
| Mini dynamic INT8 | 32 | 2142.5 ms | 2751.1 ms | 4612.7 ms | 0.423 | 0/32 | 0.0% WER · 2.87 predicted MOS |
| Mini packed INT4 | 32 | 2031.5 ms | 2647.8 ms | 4389.3 ms | 0.415 | 0/32 | 0.0% WER · 2.43 predicted MOS |
| Pico FP32 | 32 | 409.6 ms | 836.7 ms | 899.0 ms | 0.104 | 0/32 | 0.0% WER · 2.67 predicted MOS |
| Pico dynamic INT8 | 32 | 334.7 ms | 757.7 ms | 732.8 ms | 0.077 | 0/32 | 0.0% WER · 2.54 predicted MOS |
| Pico packed INT4 | 32 | 332.4 ms | 750.9 ms | 726.6 ms | 0.077 | 0/32 | 0.0% WER · 2.11 predicted MOS |

| Configuration | Median chunk audio, ms (1 / 2 / 3) | Median time until next chunk, ms | Median observed queue wait, ms | Median peak RSS, MiB |
| --- | ---: | ---: | ---: | ---: |
| Kokoro-82M FP32 | 2836.4 / 1752.4 / 2404.8 | 3310.5 / 4308.0 | 812.1 / 1984.5 | 643 |
| Kokoro-82M INT8 MatMul / FP32 | 2801.2 / 1777.5 / 2378.1 | 3158.0 / 4254.4 | 792.7 / 1923.2 | 632 |
| Mini FP32 | 3450.0 / 2300.0 / 3287.5 | 2768.5 / 4298.9 | 416.5 / 649.6 | 499 |
| Mini dynamic INT8 | 3462.5 / 2300.0 / 3300.0 | 1007.7 / 1443.8 | 0.0 / 0.0 | 346 |
| Mini packed INT4 | 3462.5 / 2300.0 / 3300.0 | 974.8 / 1401.9 | 0.0 / 0.0 | 320 |
| Pico FP32 | 3037.5 / 1900.0 / 2550.0 | 189.1 / 269.0 | 0.0 / 0.0 | 186 |
| Pico dynamic INT8 | 3037.5 / 1900.0 / 2562.5 | 154.6 / 211.8 | 0.0 / 0.0 | 180 |
| Pico packed INT4 | 3037.5 / 1900.0 / 2562.5 | 154.9 / 209.9 | 0.0 / 0.0 | 178 |

First speech and queue waits come from Android’s digital audio path. RTF is synthesis time divided by generated audio duration. The Kitten C API in this harness preserves the leading pause. The first-speech figures use the requests with a valid speech timestamp. Word error rate and predicted naturalness use the four retained renders per configuration where available.

Mini and Pico use the same native Kitten build and pinned Hugging Face FP32 checkpoints. Their INT8 and INT4 variants are local conversions of those weights. The packed INT4 rows keep INT8 and FP32 operations elsewhere. Kokoro’s INT8-weight row quantizes eligible MatMul layers and keeps its convolutions in FP32. The models retain their own voices and native frontends.

[Timing and paired confidence intervals](evidence/physical-precision-matrix/summary.json) · [Audio scores](evidence/physical-precision-matrix/quality.json) · [Device job](evidence/physical-precision-matrix/run-status.json) · [Protocol](latency/analysis/precision-matrix-protocol.md)
