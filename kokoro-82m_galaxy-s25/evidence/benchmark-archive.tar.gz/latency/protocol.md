# Galaxy S25 single-request protocol

Deadline November 21, 2026 at 21:00 Oman time (17:00 UTC). The $20 device cap covers this Kokoro lane. Use the existing no-cost allocation first. The study interprets Pico as Kitten TTS 2 Pico. Device access uses the workspace phone lock.

## Workload and comparisons

- One on-device English request from accepted text to final playback drain. Both engines receive the same complete text bytes, use speed 1.0 and generate all the text. Request fixtures are identical and are separate from screening and warmup fixtures.
- Timed interventions are Kokoro FP32 with immediate callback playback and the same Kokoro configuration with full-utterance buffering. This isolates a delivery decision from model arithmetic. Pico is a separate cross-model and cross-precision comparison using its native English voice Eleanor and mobile model. Kokoro voice is af_heart.
- Gate thread candidates against exact native float32 and playback PCM16 on the fixed screen. Search Kokoro 1, 2, 4, 6 and 8 threads and Pico 1, 2 and 4. Select the lowest median per-fixture ratio of first signal readiness versus two threads among exact candidates. Repeat complete-request confirmation on the selected configurations, with six armed rounds and all six permutations of arm order. Use a fresh app worker PID per arm and matched fixture order within each round. The normal app audio track is warmed with a separate text and ended before the first timed request.
- A same-Kokoro speed claim requires complete paired data, byte-identical native and playback PCM, valid timings, and a paired 95% whole-round bootstrap ratio interval excluding 1. The same gate applies to multi-sentence and pooled claims separately. Present each predetermined length bucket regardless of outcome. Cross-engine figures remain descriptive, with each configuration’s own voice, model and precision.

## Endpoint definitions

- First PCM callback is elapsed from the in-process request entry to the first nonempty generated audio callback. Signal readiness is when the first PCM chunk producing a nonoverlapping 5 ms window at at least 1% full-scale RMS has been converted. Both include text frontend and synthesis.
- First presented speech uses the first valid monotonic AudioTrack mapping after that window’s start frame. Subtract the time corresponding to the intervening frames at 24 kHz. An initial underrun, unusable timestamp or missing signal makes that presentation estimate unavailable. Record media volume and route. Treat the estimate as device audio-route timing. An acoustic estimate requires a captured, correlated speaker signal.
- Complete synthesis ends after the engine returns with all frames and the PCM samples are converted and retained. Report both elapsed time and elapsed divided by that request’s audio duration. Playback drain is a separate elapsed value. Model load and the first compute request are recorded once per fresh process.
- Report process RAM as Linux peak RSS (VmHWM) and Android PSS snapshots. Peak RSS includes the app runtime and instrumentation. PSS is sampled before model load, after model load, after warmup and after each request. It is not an allocation high-water mark.
- Compare timing only on matching round and fixture identities. Timing summaries give pooled and per-bucket distributions. Resample rounds as whole units. Exact playback and float hashes cover all rounds, and round-zero WAVs bind blinded listening and objective scores to the corresponding request. The listening result remains unproven without human judgments.

The installed InferenceKit HTTP audio harness has no Android AudioTrack output or microphone endpoint. These device timings are an external capture, with InferenceKit used for intake, quality policy and its offline scorer worker. [Android output timestamp reference](https://developer.android.com/reference/android/media/AudioTimestamp).
