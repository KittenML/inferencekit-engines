# Android speech quality protocol

Freeze the fixture JSONL and scorer identity before the final device capture. Use identical US English text across engines and the same native 24 kHz mono signed PCM16 export. Preserve engine-native PCM, including its trailing samples. Each fixture supplies `id`, `text`, an optional `bucket`, and optional normalized `reference_text` when the written text has a different intended spoken form. Use independent prompts with explicit endings. Score original PCM amplitudes, leading and trailing silence, and scorer transcripts as emitted.

## Exact Kokoro acceptance

Compare the incumbent and final optimized configuration on every available fixed fixture and matched measured round. Use byte equality of decoded PCM16 and require the expected sample rate, channel count and frame count. Missing captures leave the claim unproven. Invalid or all-zero WAVs and observed inequality fail the registered exact-output comparison. If the study retains only hashes for additional rounds, require the same shape and PCM hash plus a successful synthesis status in the native evidence for each claim about those rounds. Exact output preservation covers the captured fixture set and the measured configuration.

## Descriptive cross-engine quality

Use the first scheduled retained measured WAV for each fixture and arm. Mark the selected trial missing, malformed or silent where applicable. Retain denominators and score valid matching pairs. Use the same offline InferenceKit 0.1.1 audio scorer implementation on both arms, with the pinned descriptors in `scorer-descriptors.json`.

- Intelligibility proxy is micro-averaged word error rate from Faster Whisper small.en, English beam size five at temperature zero without VAD or previous-text conditioning. Normalize Unicode with NFKC, case folding and punctuation-to-space. Retain full transcripts and leave insertion-driven WER above 100% as measured.
- Completion proxy is agreement of the recognized final three normalized words with the reference ending, or the entire ending for fixtures shorter than three words. Report it with the native completion status since automatic speech recognition can misread or hallucinate a tail.
- Predicted naturalness is UTMOSv2 fusion_stage3, fold zero, checkpoint seed 42, SaruLab domain, contiguous three-second windows with the final partial window included. Report duration-weighted per-utterance values, then the mean across fixtures. This score estimates naturalness as trained by the published model and can be sensitive to clip length and domain. Use the same deterministic scorer resampling from the native WAVs for both engines.
- Cross-engine differences use the paired fixture bootstrap with 5,000 resamples and seed 20261120. Report estimates and intervals with matched and expected fixture counts. Interpret the quality comparison over these matched device-timing fixtures.
- Report native WAV frame counts, peak, RMS, rail fraction and PCM hash per row. Human naturalness and pronunciation are unproven pending blinded listening. A blind pack presents anonymized item pairs in randomized order with the corresponding prompt. Raters can score naturalness from one to five and flag incorrect or incomplete speech without access to the key. Preserve all completed ratings and the key separately.

The native Android captures use an external timing method. This pipeline uses the installed InferenceKit worker and scoring math on PCM extracted from the native captures. Different voices are intentional for independently developed TTS engines. Speaker similarity against a common speaker reference is outside this comparison.

[Faster Whisper](https://github.com/SYSTRAN/faster-whisper), [small.en](https://huggingface.co/Systran/faster-whisper-small.en/tree/d1d751a5f8271d482d14ca55d9e2deeebbae577f), [UTMOSv2](https://github.com/sarulab-speech/UTMOSv2/tree/cc2700db57bb83ee13dc31ebe1b868c254e15d09), [InferenceKit speech scoring](https://github.com/KittenML/inferencekit/blob/main/docs/audio-scorers.md).
