#!/usr/bin/env python3
"""Use InferenceKit's installed audio scorer worker on Android PCM WAVs."""

import argparse
import hashlib
from importlib.metadata import version
import itertools
import json
import math
from pathlib import Path
import random
import re
import shutil
import struct
import tempfile
import wave

from inferencekit.quality import audio, audio_scorers
from inferencekit.registry import OpError


HERE = Path(__file__).resolve().parent
NORMALIZATION = "nfkc_casefold_punctuation_v1"
SEED = 20261120
RESAMPLES = 5000


def file_sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, doc):
    with path.open("x") as stream:
        json.dump(doc, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def read_fixtures(path):
    rows = {}
    for line in path.read_text().splitlines():
        if not line.strip():
            continue
        item = json.loads(line)
        name = item["id"]
        if not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9_.-]*", name) or name in rows:
            raise ValueError(f"Invalid or duplicate fixture ID {name!r}")
        text = item["text"]
        reference = item.get("reference_text", text)
        if not audio.words(reference, NORMALIZATION) or not text.strip():
            raise ValueError(f"Empty fixture text for {name}")
        rows[name] = {**item, "reference_text": reference, "bucket": item.get("bucket", "all")}
    if not rows:
        raise ValueError("No fixtures")
    return rows


def read_capture(path, fixtures):
    try:
        data = path.read_bytes()
    except FileNotFoundError:
        return {}, None
    indexed = {}
    for line in data.decode("utf-8").splitlines():
        document = json.loads(line)
        key = document["id"]
        if key in indexed or key not in fixtures:
            raise ValueError(f"Unexpected or duplicate native fixture {key!r} in {path}")
        indexed[key] = document
    return indexed, hashlib.sha256(data).hexdigest()


def bind_capture(row, captured, metadata_sha, sample_rate):
    row["native_capture_sha256"] = metadata_sha
    if captured is None:
        row.update(status="MISSING", error="no native request row")
        return False
    if captured.get("status") != "OK":
        row.update(status="INVALID", error=captured.get("error", "native synthesis did not finish"))
        return False
    frames = captured.get("frames")
    digest = captured.get("pcm16_sha256")
    if (captured.get("bucket") != row["bucket"] or type(frames) is not int or frames <= 0
            or captured.get("sample_rate") != sample_rate or not isinstance(digest, str)
            or not re.fullmatch(r"[a-f0-9]{64}", digest)):
        row.update(status="INVALID", error="native request row has invalid identity or PCM shape")
        return False
    row.update(frames=frames, pcm_sha256=digest, sample_rate=sample_rate)
    native_float = captured.get("float32_pcm_sha256")
    if isinstance(native_float, str) and re.fullmatch(r"[a-f0-9]{64}", native_float):
        row["float32_pcm_sha256"] = native_float
    return True


def load_wavs(fixtures, arms, rounds, scratch, sample_rate, bind_native):
    rows, raw_files, jobs = {}, {}, []
    for arm, root in arms.items():
        for index, label in enumerate(rounds):
            directory = root / label if label is not None else root
            capture, metadata_sha = read_capture(directory / "requests.jsonl", fixtures) if bind_native else ({}, None)
            for fixture, document in fixtures.items():
                key = (arm, index, fixture)
                wav_path = directory / f"{fixture}.wav"
                row = {"arm": arm, "fixture": fixture, "round": label, "bucket": document["bucket"]}
                rows[key] = row
                if bind_native and not bind_capture(row, capture.get(fixture), metadata_sha, sample_rate):
                    continue
                if index > 0 and bind_native and not wav_path.exists():
                    row["status"] = "HASH_ONLY"
                    continue
                try:
                    with wave.open(str(wav_path), "rb") as stream:
                        frames = stream.getnframes()
                        if (stream.getnchannels(), stream.getframerate(), stream.getsampwidth()) != (1, sample_rate, 2):
                            raise ValueError(f"expected mono {sample_rate} Hz PCM16")
                        raw = stream.readframes(frames)
                    if len(raw) != frames * 2 or not frames:
                        raise ValueError("empty or truncated PCM")
                except (OSError, EOFError, ValueError, wave.Error) as err:
                    row["status"] = "MISSING" if not wav_path.exists() else "INVALID"
                    row["error"] = type(err).__name__
                    if isinstance(err, ValueError):
                        row["error"] = str(err)
                    continue
                pcm_hash = hashlib.sha256(raw).hexdigest()
                if bind_native and (pcm_hash != row["pcm_sha256"] or frames != row["frames"]):
                    row.update(status="INVALID", error="WAV PCM does not match native request row",
                               wav_pcm_sha256=pcm_hash, wav_frames=frames)
                    continue
                raw_path = scratch / pcm_hash
                if not raw_path.exists():
                    raw_path.write_bytes(raw)
                raw_files[key] = (raw_path, wav_path)
                values = [value for (value,) in struct.iter_unpack("<h", raw)]
                maxabs = max(abs(value) for value in values)
                clipped = sum(value in (-32768, 32767) for value in values)
                row.update(
                    frames=frames,
                    pcm_sha256=pcm_hash,
                    wav_sha256=file_sha(wav_path),
                    sample_rate=sample_rate,
                    peak=maxabs / 32768,
                    rms=math.sqrt(sum(value * value for value in values) / frames) / 32768,
                    rail_fraction=clipped / frames,
                    status="OK" if maxabs else "SILENT",
                )
                # First requested round is fixed before scoring. Missing speech stays missing.
                if index == 0 and maxabs:
                    jobs.append({
                        "arm": arm, "id": fixture, "round": 0, "seed": SEED,
                        "pcm_sha256": pcm_hash,
                        "text_sha256": hashlib.sha256(document["text"].encode()).hexdigest(),
                        "sample_rate": sample_rate, "sample_count": frames,
                        "channels": 1, "pcm_path": str(raw_path),
                    })
    return rows, raw_files, jobs


def compare_pcm(fixtures, rounds, rows, raw_files, pairs):
    comparisons = []
    for left, right in pairs:
        details = []
        for index, label in enumerate(rounds):
            for fixture in fixtures:
                a, b = (left, index, fixture), (right, index, fixture)
                detail = {"fixture": fixture, "round": label}
                statuses = {rows[a]["status"], rows[b]["status"]}
                if statuses == {"OK"}:
                    detail.update(audio.parity(raw_files[a][0].read_bytes(), raw_files[b][0].read_bytes(), 1))
                    detail["comparison"] = "decoded PCM16 bytes"
                    detail["status"] = "PASS" if detail["bit_exact"] else "FAIL"
                elif statuses <= {"OK", "HASH_ONLY"}:
                    same_frames = rows[a]["frames"] == rows[b]["frames"]
                    same_pcm = same_frames and rows[a]["pcm_sha256"] == rows[b]["pcm_sha256"]
                    detail.update(comparison="native PCM16 SHA-256 and shape", same_sample_count=same_frames,
                                  bit_exact=same_pcm, status="PASS" if same_pcm else "FAIL")
                elif statuses & {"INVALID", "SILENT"}:
                    detail["status"] = "FAIL"
                else:
                    detail["status"] = "UNPROVEN"
                if statuses <= {"OK", "HASH_ONLY"} and all("float32_pcm_sha256" in rows[key] for key in (a, b)):
                    detail["native_float32_hash_match"] = rows[a]["float32_pcm_sha256"] == rows[b]["float32_pcm_sha256"]
                details.append(detail)
        statuses = {row["status"] for row in details}
        verdict = "FAIL" if "FAIL" in statuses else "UNPROVEN" if "UNPROVEN" in statuses else "PASS"
        comparisons.append({"baseline": left, "candidate": right, "status": verdict, "pairs": details})
    return comparisons


def score(config_path, registered_path, jobs, rows, fixtures):
    if not jobs:
        return {}
    config = audio_scorers.load_config(config_path)
    registered = json.loads(registered_path.read_text())
    status = {}
    for name, spec in config["scorers"].items():
        worker_config = {**config, "scorers": {name: spec}}
        descriptor = {**registered, "scorers": {name: registered["scorers"][name]}}
        try:
            result = audio_scorers.run_worker(worker_config, "score", {
                "descriptors": descriptor, "jobs": jobs,
            })
        except OpError as err:
            status[name] = {"status": "UNPROVEN", "error": str(err)}
            continue
        status[name] = {"status": "MEASURED", "scored": len(result["rows"])}
        for observation in result["rows"]:
            row = rows[(observation["arm"], 0, observation["id"])]
            assert row["pcm_sha256"] == observation["pcm_sha256"]
            if name == "asr":
                reference = fixtures[observation["id"]]["reference_text"]
                transcript = observation["asr"]["text"]
                last = audio.words(reference, NORMALIZATION)[-3:]
                spoken = audio.words(transcript, NORMALIZATION)
                row.update(
                    transcript=transcript,
                    text_sha256=observation["text_sha256"],
                    **audio.word_error(reference, transcript, NORMALIZATION),
                    recognized_final_words=spoken[-len(last):] == last,
                )
            elif name == "naturalness":
                row["utmosv2_windows"] = observation["naturalness"]["windows"]
                row["predicted_mos"] = audio.window_score(
                    observation["naturalness"], row["frames"], descriptor["scorers"][name],
                )
    return status


def metric_rows(rows, key):
    if not rows:
        return None
    if key == "wer":
        return sum(row["errors"] for row in rows) / sum(row["words"] for row in rows)
    return sum(row[key] for row in rows) / len(rows)


def bootstrap(pairs, key):
    rng = random.Random(SEED)
    draws = []
    for _ in range(RESAMPLES):
        left, right = zip(*rng.choices(pairs, k=len(pairs)))
        draws.append(metric_rows(right, key) - metric_rows(left, key))
    draws.sort()
    return [draws[math.floor((len(draws) - 1) * p)] for p in (0.025, 0.975)]


def summarize(fixtures, arms, rows, exact_pairs):
    metrics = ("wer", "recognized_final_words", "predicted_mos")
    summaries, deltas = [], []
    groups = {bucket: [key for key, item in fixtures.items() if item["bucket"] == bucket]
              for bucket in sorted({item["bucket"] for item in fixtures.values()} - {"all"})}
    groups["all"] = list(fixtures)
    for bucket, selected in groups.items():
        for arm in arms:
            observed = [rows[arm, 0, fixture] for fixture in selected]
            for metric in metrics:
                available = [row for row in observed if metric in row]
                summaries.append({"arm": arm, "bucket": bucket, "metric": metric,
                                  "value": metric_rows(available, metric),
                                  "scored": len(available), "expected": len(observed)})
        exact_sets = {frozenset(pair) for pair in exact_pairs}
        for left, right in itertools.combinations(arms, 2):
            if frozenset((left, right)) in exact_sets:
                continue
            for metric in metrics:
                matched = [(rows[left, 0, item], rows[right, 0, item]) for item in selected
                           if metric in rows[left, 0, item] and metric in rows[right, 0, item]]
                a, b = zip(*matched) if matched else ([], [])
                deltas.append({
                    "left": left, "right": right, "bucket": bucket, "metric": metric,
                    "left_value": metric_rows(a, metric), "right_value": metric_rows(b, metric),
                    "delta_right_minus_left": metric_rows(b, metric) - metric_rows(a, metric) if matched else None,
                    "ci95": bootstrap(matched, metric) if len(matched) > 1 else None,
                    "pairs": len(matched), "expected_pairs": len(selected),
                })
    return summaries, deltas


def blind_pack(destination, pair, fixtures, rows, raw_files):
    destination.mkdir(parents=True)
    rng = random.Random(SEED)
    key, ratings = [], ["clip,rater,pronunciation_or_completion_error,naturalness_1_to_5,notes"]
    for index, (fixture, item) in enumerate(fixtures.items(), start=1):
        order = list(pair)
        rng.shuffle(order)
        if any(rows[arm, 0, fixture]["status"] != "OK" for arm in order):
            continue
        for letter, arm in zip(("A", "B"), order):
            name = f"{index:03d}-{letter}"
            shutil.copyfile(raw_files[arm, 0, fixture][1], destination / f"{name}.wav")
            key.append({"clip": name, "fixture": fixture, "arm": arm})
            ratings.append(f"{name},,,,")
    dump(destination.parent / f"{destination.name}-answer-key.json", key)
    dump(destination / "text.json", [{"pair": f"{index:03d}", "text": item["reference_text"]}
                                     for index, (fixture, item) in enumerate(fixtures.items(), start=1)
                                     if all(rows[arm, 0, fixture]["status"] == "OK" for arm in pair)])
    (destination / "ratings.csv").write_text("\n".join(ratings) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixtures", type=Path, required=True)
    parser.add_argument("--arm", action="append", required=True, metavar="LABEL=WAV_DIR")
    parser.add_argument("--round", action="append", metavar="WAV_SUBDIRECTORY")
    parser.add_argument("--exact", action="append", default=[], metavar="BASELINE=CANDIDATE")
    parser.add_argument("--sample-rate", type=int, default=24000)
    parser.add_argument("--bind-native", action="store_true", help="validate PCM against each round's requests.jsonl")
    parser.add_argument("--parity-only", action="store_true")
    parser.add_argument("--config", type=Path, default=HERE / "scorers.json")
    parser.add_argument("--registered", type=Path, default=HERE / "scorer-descriptors.json")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--blind-pack", type=Path)
    parser.add_argument("--blind-pair", metavar="LEFT=RIGHT")
    options = parser.parse_args()
    arms = {}
    for spec in options.arm:
        name, path = spec.split("=", 1)
        if not name or name in arms or not path:
            parser.error(f"Invalid or duplicate arm {spec!r}")
        arms[name] = Path(path).resolve()
    exact_pairs = [tuple(spec.split("=", 1)) for spec in options.exact]
    blind_pair = tuple(options.blind_pair.split("=", 1)) if options.blind_pair else tuple(arms)[:2]
    for pair in [*exact_pairs, *([blind_pair] if options.blind_pack else [])]:
        if len(pair) != 2 or pair[0] == pair[1] or any(arm not in arms for arm in pair):
            parser.error(f"Invalid pair {pair}")
    rounds = options.round or [None]
    if len(rounds) != len(set(rounds)):
        parser.error("Duplicate round")
    fixtures = read_fixtures(options.fixtures)
    with tempfile.TemporaryDirectory(prefix="android-speech-pcm-") as scratch:
        rows, raw_files, jobs = load_wavs(fixtures, arms, rounds, Path(scratch), options.sample_rate, options.bind_native)
        exact = compare_pcm(fixtures, rounds, rows, raw_files, exact_pairs)
        scorers = {} if options.parity_only else score(options.config, options.registered, jobs, rows, fixtures)
        summaries, deltas = ([], []) if options.parity_only else summarize(fixtures, arms, rows, exact_pairs)
        if options.blind_pack:
            blind_pack(options.blind_pack, blind_pair, fixtures, rows, raw_files)
        dump(options.out, {
            "format": "android-wav-speech-quality-v1",
            "timing_harness": "External native Android benchmark",
            "scorer_implementation": f"InferenceKit {version('inferencekit-cli')} unmodified audio scorer worker",
            "fixtures_sha256": file_sha(options.fixtures),
            "quality_protocol_sha256": file_sha(HERE / "protocol.md"),
            "scorer_descriptor_sha256": None if options.parity_only else file_sha(options.registered),
            "sample_rate": options.sample_rate,
            "bound_to_native_request_rows": options.bind_native,
            "normalization": NORMALIZATION,
            "seed": SEED, "bootstrap_draws": RESAMPLES,
            "scored_round": rounds[0], "captured_rounds": rounds,
            "scorers": scorers, "rows": list(rows.values()), "exact_pcm": exact,
            "per_arm": summaries, "paired_differences": deltas, "human_listening": "UNPROVEN",
        })


if __name__ == "__main__":
    main()
