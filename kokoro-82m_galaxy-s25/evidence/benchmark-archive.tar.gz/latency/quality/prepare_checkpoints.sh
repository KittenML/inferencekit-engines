#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
cache="${1:-}"
while IFS=$'\t' read -r file repo revision sha; do
  target="checkpoints/$file"
  mkdir -p "$(dirname "$target")"
  if [[ ! -f "$target" ]]; then
    if [[ -n "$cache" && -f "$cache/$file" ]]; then
      cp --reflink=auto "$cache/$file" "$target.partial"
    else
      curl --fail --location --silent --show-error --retry 2 --max-time 1200 \
        "https://huggingface.co/$repo/resolve/$revision/${file##*/}?download=true" \
        -o "$target.partial"
    fi
    printf '%s  %s\n' "$sha" "$target.partial" | sha256sum --check --status
    mv "$target.partial" "$target"
  fi
  printf '%s  %s\n' "$sha" "$target" | sha256sum --check
done < checkpoints.tsv
