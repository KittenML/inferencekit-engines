# Reproduce the speech checks

The Android capture supplies `results/<arm>/round-0/<id>.wav`, with optional directories for later measured rounds. Run these commands from the Kokoro study directory. The protocol and its frozen input hashes are in [protocol.md](protocol.md) and [registration.sha256](registration.sha256).

Recreate the scorer environment if needed. This study used CPython 3.11.13 for the model scorers and InferenceKit CLI 0.1.1 from [commit 6a85e50](https://github.com/KittenML/inferencekit/tree/6a85e5075fe65399bf2648e045b993997c32da9e).

```bash
uv venv --python 3.11 quality/.venv
uv pip sync --python quality/.venv/bin/python --extra-index-url https://download.pytorch.org/whl/cpu quality/scorer-requirements.txt
quality/prepare_checkpoints.sh
inferencekit quality audio-scorers quality/scorers.json --json
```

Use the Python environment that owns the installed InferenceKit 0.1.1 CLI for `score.py`. It starts the offline scorer worker in the separate pinned environment. The six-round confirmation retains WAVs in `round-0` and `requests.jsonl` in each round. The scorer binds the first-round WAVs to their on-device PCM hashes and frame counts. Later exact checks compare the native PCM hashes and frame counts.

```bash
(cd quality && sha256sum --check registration.sha256)
ik_python=$(sed -n '1s/^#!//p' "$(command -v inferencekit)")
"$ik_python" quality/score.py \
  --fixtures fixtures/requests.jsonl --bind-native \
  --round round-0 --round round-1 --round round-2 --round round-3 --round round-4 --round round-5 \
  --arm kokoro_buffered=results/kokoro_buffered \
  --arm kokoro_stream=results/kokoro_stream \
  --arm pico_stream=results/pico_stream \
  --exact kokoro_buffered=kokoro_stream \
  --blind-pair kokoro_stream=pico_stream \
  --blind-pack quality/listen \
  --out quality/scores.json
```

Add `--parity-only` for a capture check without ASR or predicted naturalness. The scoring wrapper is for native Android WAV evidence. The standard InferenceKit policy-registration record freezes the matching fixture IDs and texts plus the exact PCM policy. It has the expected `NOT RUN` verdict because it registers policy without running the HTTP benchmark.
