"""Report first-speech observations from the separate same-phone mic diagnostic."""
import argparse
from collections import Counter
import json
from pathlib import Path

from timing import ARMS, PAIRS, number, paired, stats


MATCHED = "matched-speaker-at-phone-mic"
NEGATIVE = {"no-acoustic-match", "weak-or-ambiguous-match"}


def read(path, default):
    try:
        return json.loads(path.read_text())
    except FileNotFoundError:
        return default


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--fixtures", type=Path, default=Path("fixtures/requests.jsonl"))
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--rounds", type=int, default=6)
    args = parser.parse_args()
    fixtures = {v["id"]: v["bucket"] for v in map(json.loads, args.fixtures.read_text().splitlines())}
    ids_by_bucket = {bucket: [key for key, value in fixtures.items() if value == bucket]
                     for bucket in sorted(set(fixtures.values()))}
    ids_by_bucket["overall"] = list(fixtures)
    results = {"source": "separate Android built-in speaker-to-microphone diagnostic",
               "rounds": args.rounds, "arms": {}, "comparisons": []}
    all_elapsed = {}
    for arm in ARMS:
        statuses = Counter()
        elapsed = [{} for _ in range(args.rounds)]
        controls = []
        for i in range(args.rounds):
            directory = args.results / arm / f"round-{i}"
            metadata = read(directory / "done.json", {})
            positive = metadata.get("audio_warmup", {}).get("acoustic", {}).get("status")
            negative = metadata.get("muted_control", {}).get("acoustic", {}).get("status")
            media_volume = metadata.get("media_volume", 0)
            controls_pass = positive == MATCHED and negative in NEGATIVE and number(media_volume, 1)
            controls.append({"round": i, "speaker_on": positive, "speaker_muted": negative,
                             "media_volume": media_volume, "valid": controls_pass})
            try:
                rows = [json.loads(line) for line in (directory / "requests.jsonl").read_text().splitlines()]
            except FileNotFoundError:
                continue
            for row in rows:
                acoustic = row.get("acoustic", {})
                status = acoustic.get("status", "missing")
                statuses[status] += 1
                value = acoustic.get("matched_after_request_ms")
                if status == MATCHED and controls_pass and number(value):
                    elapsed[i][row["id"]] = value
        results["arms"][arm] = {"acoustic_statuses": dict(statuses), "controls": controls,
            "matched_ms": {bucket:stats(value for group in elapsed for key, value in group.items()
                                       if key in ids) for bucket, ids in ids_by_bucket.items()}}
        all_elapsed[arm] = elapsed
    for left, right in PAIRS:
        groups_left, groups_right = all_elapsed[left], all_elapsed[right]
        results["comparisons"].append({"baseline": left, "candidate": right,
            "buckets": {bucket: paired([[(x[key], y[key]) for key in ids if key in x and key in y]
                                       for x, y in zip(groups_left, groups_right)],
                                      len(ids), args.rounds, 5000)
                        for bucket, ids in ids_by_bucket.items()}})
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
