"""Write the local comparison report from verified timing and speech evidence."""
import argparse
import json
import os
from pathlib import Path

LABELS = {
    "kokoro_fp32": "Kokoro-82M FP32",
    "kokoro_int8": "Kokoro-82M INT8 MatMul / FP32",
    "mini_fp32": "Mini FP32",
    "mini_int8": "Mini dynamic INT8",
    "mini_int4": "Mini packed INT4",
    "pico_fp32": "Pico FP32",
    "pico_int8": "Pico dynamic INT8",
    "pico_int4": "Pico packed INT4",
}


def stat(summary, name, value="p95"):
    result = summary.get(name)
    return f"{result[value]:.1f}" if result else "Unavailable"


def intervals(stats, key):
    values = stats.get(key)
    return " / ".join(f"{row['median']:.1f}" for row in values) if values else "Unavailable"


def format_quality(stats, scores):
    flags = []
    if stats["requests_without_speech_onset"] or stats["requests_with_nonfinite_pcm"]:
        flags.append("Broken audio observed")
    wer = scores.get("wer")
    mos = scores.get("predicted_mos")
    endings = scores.get("recognized_final_words")
    if not wer or not mos or not endings:
        return " · ".join([*flags, "Scoring unavailable"])
    if endings["value"] < 1:
        flags.append(f"{round(endings['value'] * endings['scored'])}/{endings['expected']} endings recognized")
    return " · ".join([f"{100 * wer['value']:.1f}% WER", f"{mos['value']:.2f} predicted MOS", *flags])


def report(timing, speech, source, report_path):
    link = os.path.relpath(source, report_path.parent)
    device = timing["device"]
    audio_scores = {arm: {} for arm in LABELS}
    for row in speech["per_arm"]:
        if row["bucket"] == "all":
            audio_scores[row["arm"]][row["metric"]] = row
    out = [
        "# Galaxy S25 TTS precision comparison",
        "",
        f"One physical Galaxy S25 ({device['model']}, Android {device['android']}), one warm request at a time.",
        "Every engine received the same four English prompts split into the same three sentences. "
        "All workers used two inference threads and immediate AudioTrack playback.",
        "",
        "| Configuration | Requests timed | First PCM p95 | First speech p95 | Synthesis p95 | Median RTF | Underrun requests | Retained audio |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |",
    ]
    chunk_rows, errors = [], []
    for arm, label in LABELS.items():
        entry = timing["arms"][arm]
        stats = entry["pooled"]
        if stats is None:
            out.append(f"| {label} | 0 | NOT RUN | NOT RUN | NOT RUN | NOT RUN | NOT RUN | Unavailable |")
        else:
            underruns = (f"{stats['requests_with_audiotrack_underrun']}/{stats['valid_playback']}"
                         if stats["valid_playback"] else "Unavailable")
            measured = [stat(stats, key) for key in (
                "first_callback_ms", "first_presented_signal_ms", "synthesis_complete_ms")]
            ms = " | ".join(f"{value} ms" if value != "Unavailable" else value for value in measured)
            out.append(f"| {label} | {stats['requests']} | {ms} | {stats['rtf']['median']:.3f} | "
                       f"{underruns} | {format_quality(stats, audio_scores[arm])} |")
            rss = stats["vm_hwm_kib"]["median"] / 1024
            chunk_rows.append(f"| {label} | {intervals(stats, 'chunk_audio_ms')} | "
                              f"{intervals(stats, 'next_chunk_ready_interval_ms')} | "
                              f"{intervals(stats, 'observed_queue_empty_wait_ms')} | {rss:.0f} |")
        for issue in entry["errors"]:
            message = str(issue["error"]).replace("\n", " ")
            errors.append(f"- {issue['label']} {issue.get('id', '')} — {issue['verdict']}. `{message}`")
    out += [
        "",
        "| Configuration | Median chunk audio, ms (1 / 2 / 3) | Median time until next chunk, ms | Median observed queue wait, ms | Median peak RSS, MiB |",
        "| --- | ---: | ---: | ---: | ---: |",
        *chunk_rows,
        "",
        "First speech and queue waits come from Android’s digital audio path. "
        "RTF is synthesis time divided by generated audio duration. "
        "The Kitten C API in this harness preserves the leading pause. "
        "The first-speech figures use the requests with a valid speech timestamp. "
        "Word error rate and predicted naturalness use the four retained renders per configuration where available.",
        "",
        "Mini and Pico use the same native Kitten build and pinned Hugging Face FP32 checkpoints. "
        "Their INT8 and INT4 variants are local conversions of those weights. "
        "The packed INT4 rows keep INT8 and FP32 operations elsewhere. "
        "Kokoro’s INT8-weight row quantizes eligible MatMul layers and keeps its convolutions in FP32. "
        "The models retain their own voices and native frontends.",
        "",
        f"[Timing and paired confidence intervals]({link}/summary.json) · "
        f"[Audio scores]({link}/quality.json) · [Playable clips]({link}/review-input/review/index.html) · "
        f"[Device job]({link}/run-status.json) · [Protocol](analysis/precision-matrix-protocol.md)",
    ]
    if errors:
        out.extend(["", "## Timing errors", "", *errors])
    return "\n".join(out) + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capture", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    timing = json.loads((args.capture / "summary.json").read_text())
    speech = json.loads((args.capture / "quality.json").read_text())
    args.output.write_text(report(timing, speech, args.capture, args.output))


if __name__ == "__main__":
    main()
