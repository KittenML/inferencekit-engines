"""Audit and summarize the Android app's matched speech timing records."""

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import random
import re
from statistics import median


ARMS = {"kokoro_buffered": ("kokoro", False), "kokoro_stream": ("kokoro", True),
        "pico_stream": ("pico", True)}
PAIRS = [("kokoro_buffered", "kokoro_stream"), ("kokoro_stream", "pico_stream")]
ORDER = [(0, 1, 2), (2, 0, 1), (1, 2, 0), (2, 1, 0), (1, 0, 2), (0, 2, 1)]
REQUEST_METRICS = (
    "first_callback_ms", "first_signal_ready_ms", "first_presented_signal_ms", "play_call_ms",
    "synthesis_complete_ms", "rtf", "playback_drained_ms", "presentation_to_drain_ms",
    "duration_s", "frames", "callbacks",
    "post_request_pss_kib", "vm_hwm_kib", "audio_write_underruns", "clipped_samples",
)
ROUND_METRICS = (
    "load_ms", "start_service_to_loaded_ms", "pss_before_load_kib", "pss_after_load_kib",
    "rss_after_load_kib", "pss_after_warmup_kib", "max_post_request_pss_kib", "vm_hwm_kib",
)
PAIRED_METRICS = (
    "first_callback_ms", "first_signal_ready_ms", "first_presented_signal_ms",
    "synthesis_complete_ms", "rtf", "playback_drained_ms", "presentation_to_drain_ms", "duration_s",
    "post_request_pss_kib", "vm_hwm_kib",
)
CONDITION_KEYS = ("model", "device", "board", "soc", "android", "abis", "thermal_status",
                  "power_save", "battery_temperature_tenths_c", "battery_plugged")
ROUTE_KEYS = ("audio_route_type", "audio_buffer_frames", "audio_start_threshold_frames",
              "audio_performance_mode")
PCM_KEYS = ("float32_pcm_sha256", "pcm16_sha256")
HASH = re.compile(r"[a-f0-9]{64}")
SEED = 584399


def number(value, minimum=0):
    return type(value) in (int, float) and math.isfinite(value) and value >= minimum


def percentile(sorted_values, fraction):
    position = (len(sorted_values) - 1) * fraction
    low = math.floor(position)
    high = math.ceil(position)
    return sorted_values[low] + (position - low) * (sorted_values[high] - sorted_values[low])


def stats(values):
    values = sorted(value for value in values if number(value))
    if not values:
        return {"n": 0, "min": None, "p50": None, "p95": None, "max": None}
    return {"n": len(values), "min": values[0], "p50": median(values),
            "p95": percentile(values, 0.95), "max": values[-1]}


def read(path, lines=False):
    data = path.read_text(encoding="utf-8")
    if lines:
        return [json.loads(line) for line in data.splitlines() if line.strip()]
    return json.loads(data)


def read_checked(path, issues, location, lines=False):
    if lines:
        try:
            data = path.read_text(encoding="utf-8")
        except OSError:
            issues.append({**location, "issue": f"missing_{path.name}"})
            return []
        rows = []
        for line_no, line in enumerate(data.splitlines(), 1):
            if not line.strip():
                continue
            try:
                value = json.loads(line)
                if not isinstance(value, dict):
                    raise ValueError
                rows.append(value)
            except ValueError:
                issues.append({**location, "issue": f"invalid_line_in_{path.name}", "line": line_no})
        return rows
    try:
        value = read(path)
        if not isinstance(value, dict):
            raise ValueError
        return value
    except (OSError, ValueError):
        issues.append({**location, "issue": f"missing_or_invalid_{path.name}"})
        return {}


def is_hash(value):
    return isinstance(value, str) and HASH.fullmatch(value) is not None


def complete(row, fixture):
    if row.get("status") != "OK":
        return "request_failed"
    chars = len(fixture["text"].encode("utf-16-le")) // 2
    if row.get("bucket") != fixture["bucket"] or row.get("chars") != chars:
        return "fixture_mismatch"
    frames = row.get("frames")
    onset = row.get("onset_frame")
    if (type(frames) is not int or frames < 1 or row.get("sample_rate") != 24000
            or type(onset) is not int or not 0 <= onset < frames
            or not number(row.get("callbacks"), 1) or not all(is_hash(row.get(k)) for k in PCM_KEYS)):
        return "invalid_audio_shape_or_hash"
    duration, rtf, synthesis = (row.get(k) for k in ("duration_s", "rtf", "synthesis_complete_ms"))
    callback, signal = (row.get(k) for k in ("first_callback_ms", "first_signal_ready_ms"))
    if (not all(number(value) for value in (duration, rtf, synthesis, callback, signal))
            or not 0 <= callback <= signal <= synthesis
            or not math.isclose(duration, frames / 24000, rel_tol=1e-6)
            or not math.isclose(rtf, synthesis / (duration * 1000), rel_tol=1e-6)):
        return "invalid_synthesis_timing"
    return None


def playback_complete(row):
    start, drained = (row.get(k) for k in ("play_call_ms", "playback_drained_ms"))
    return (not row.get("audio_playback_error") and row.get("audio_written_frames") == row.get("frames")
            and number(start) and number(drained) and start <= drained
            and row["synthesis_complete_ms"] <= drained)


def clock_issue(row, play):
    if not play:
        return "playback_not_run"
    if not playback_complete(row):
        return "incomplete_playback"
    underruns = row.get("audio_start_underruns")
    if not number(underruns):
        return "inconsistent_timestamp"
    if underruns > 0:
        return "underrun_before_onset"
    value = row.get("first_presented_signal_ms")
    if value is None:
        return "no_valid_timestamp"
    if (not number(value) or not row["play_call_ms"] <= value <= row["playback_drained_ms"]
            or not number(row.get("timestamp_frame"), row["onset_frame"] + 1)
            or row["timestamp_frame"] > row["frames"]
            or not number(row.get("timestamp_ns"), 1) or not number(row.get("start_monotonic_ns"), 1)):
        return "inconsistent_timestamp"
    offset_ms = ((row["timestamp_ns"] - row["start_monotonic_ns"]) / 1e6
                 - (row["timestamp_frame"] - row["onset_frame"]) / 24)
    if not math.isclose(offset_ms, value, abs_tol=0.001):
        return "inconsistent_timestamp"
    return None


def route(row):
    name = row.get("audio_route_name")
    return (*[row.get(key) for key in ROUTE_KEYS],
            hashlib.sha256(name.encode()).hexdigest() if isinstance(name, str) else None)


def member_data(arm, round_no, directory, fixtures, issues):
    location = {"arm": arm, "round": round_no}
    done = read_checked(directory / "done.json", issues, location)
    rows = read_checked(directory / "requests.jsonl", issues, location, lines=True)
    engine, stream = ARMS[arm]
    if (done.get("round") != round_no or done.get("label") != f"{arm}/round-{round_no}"
            or done.get("label_engine") != engine or done.get("stream") is not stream
            or done.get("screen") is not False or type(done.get("play")) is not bool
            or not number(done.get("pid"), 1) or not number(done.get("threads"), 1)):
        issues.append({**location, "issue": "invalid_round_configuration"})
        return done, {}, Counter()
    if done.get("status") != "OK":
        issues.append({**location, "issue": "worker_failed_or_partial"})

    present = {row.get("id") for row in rows if isinstance(row.get("id"), str)}
    duplicates = Counter(row.get("id") for row in rows if isinstance(row.get("id"), str))
    for missing in fixtures.keys() - present:
        issues.append({**location, "id": missing, "issue": "request_missing"})
    valid, clock_issues = {}, Counter()
    for row in rows:
        fixture_id = row.get("id") if isinstance(row.get("id"), str) else None
        issue_location = {**location, "id": fixture_id if fixture_id in fixtures else None}
        if fixture_id not in fixtures or duplicates[fixture_id] != 1:
            reason = "unexpected_request" if fixture_id not in fixtures else "duplicate_request"
        else:
            reason = complete(row, fixtures[fixture_id])
        if reason:
            issues.append({**issue_location, "issue": reason})
            continue
        reason = clock_issue(row, done["play"])
        if reason:
            row["first_presented_signal_ms"] = None
            if reason == "incomplete_playback":
                row["playback_drained_ms"] = None
            clock_issues[reason] += 1
            if done["play"]:
                issues.append({**issue_location, "issue": reason})
        else:
            row["presentation_to_drain_ms"] = (
                row["playback_drained_ms"] - row["first_presented_signal_ms"]
            )
        valid[fixture_id] = row
    return done, valid, clock_issues


def distribution(rows, keys):
    return {key: stats(row.get(key) for row in rows) for key in keys}


def repeat_audio(samples, ids):
    repeat_counts = {key: sum(key in rows for rows in samples) for key in ids}
    differing = [key for key in ids if len({(rows[key]["frames"], *(rows[key][k] for k in PCM_KEYS))
                                           for rows in samples if key in rows}) > 1]
    return {"requests_with_repeats": sum(count > 1 for count in repeat_counts.values()),
            "requests_measured_in_all_rounds": sum(count == len(samples) for count in repeat_counts.values()),
            "request_ids_with_changed_pcm_or_frames": differing}


def paired_estimators(pairs):
    left, right = zip(*pairs)
    p50_left, p50_right = median(left), median(right)
    p95_left, p95_right = (percentile(sorted(values), 0.95) for values in (left, right))
    return {"p50_candidate_minus_baseline": p50_right - p50_left,
            "p95_candidate_minus_baseline": p95_right - p95_left,
            "median_paired_candidate_minus_baseline": median(right - left for left, right in pairs),
            "p50_candidate_over_baseline": p50_right / p50_left if p50_left > 0 else None,
            "p95_candidate_over_baseline": p95_right / p95_left if p95_left > 0 else None}


def paired(groups, fixtures_per_round, rounds, resamples):
    available = [pair for group in groups for pair in group]
    full = [group for group in groups if len(group) == fixtures_per_round]
    result = {"n_pairs": len(available), "expected_pairs": rounds * fixtures_per_round,
              "rounds_with_pairs": sum(bool(group) for group in groups),
              "complete_paired_rounds": len(full), "point": None, "ci95": None}
    if not available:
        return result
    result["point"] = paired_estimators(available)
    if len(full) < 3:
        return result
    rng = random.Random(SEED)
    values = defaultdict(list)
    for _ in range(resamples):
        draw = [pair for group in rng.choices(full, k=len(full)) for pair in group]
        for key, value in paired_estimators(draw).items():
            if value is not None:
                values[key].append(value)
    result["ci95"] = {}
    result["ci95_point_complete_rounds_only"] = paired_estimators([pair for group in full for pair in group])
    for key, samples in values.items():
        if len(samples) == resamples:
            samples.sort()
            result["ci95"][key] = [percentile(samples, 0.025), percentile(samples, 0.975)]
    return result


def audio_checks(samples, summaries):
    paths = Counter()
    volume = Counter()
    continuity = defaultdict(Counter)
    for round_no, rows in enumerate(samples):
        for row in rows.values():
            if "audio_route_type" in row:
                paths[route(row)] += 1
            underruns = row.get("audio_write_underruns")
            if playback_complete(row) and number(underruns):
                for key in ("overall", row["bucket"]):
                    continuity[key]["complete_playbacks"] += 1
                    continuity[key]["with_underrun"] += underruns > 0
        settings = summaries[round_no]
        if settings.get("play"):
            volume[(settings.get("media_volume"), settings.get("media_volume_max"))] += 1
    # Product names can contain labels set by the device owner.
    return {"paths": [{**dict(zip(ROUTE_KEYS, keys[:-1])), "route_name_sha256": keys[-1],
                       "requests": count} for keys, count in paths.items()],
            "media_volume": [{"index": levels[0], "max": levels[1], "rounds": count}
                             for levels, count in volume.items()],
            "continuity": {key: dict(counts) for key, counts in continuity.items()},
            "route_settings_matched_within_arm": len(paths) == 1 and number(next(iter(paths))[0], 1) if paths else None,
            "volume_nonzero_for_all_playback_rounds": all(number(levels[0], 1) and number(levels[1], 1)
                                                          and levels[0] <= levels[1] for levels in volume) if volume else None}


def condition_view(summaries, starts):
    values = {key: [] for key in CONDITION_KEYS}
    for done in summaries:
        for key, value in (done.get(starts) or {}).items():
            if key in values and value not in values[key]:
                values[key].append(value)
    return values


def pair_conditions(left, right, keys):
    return all(left.get(k) is not None and left.get(k) == right.get(k) for k in keys)


def compare(left, right, a, b, summaries, buckets, rounds, resamples):
    result = {"baseline": left, "candidate": right, "buckets": {}}
    left_done, right_done = summaries[left], summaries[right]
    for bucket, ids in buckets.items():
        pairs = [{fixture_id: (a[i][fixture_id], b[i][fixture_id]) for fixture_id in ids
                  if fixture_id in a[i] and fixture_id in b[i]} for i in range(rounds)]
        status = {"complete_synthesis_pairs": sum(len(group) for group in pairs),
                  "complete_playback_pairs": 0, "route_settings_matching_pairs": 0,
                  "known_route_settings_matching_pairs": 0, "volume_settings_matching_pairs": 0,
                  "positive_matched_volume_pairs": 0, "native_pcm_equal_pairs": 0, "pcm16_equal_pairs": 0}
        mismatches = []
        for i, group in enumerate(pairs):
            for fixture_id, (x, y) in group.items():
                same_native = x[PCM_KEYS[0]] == y[PCM_KEYS[0]]
                same_pcm16 = x[PCM_KEYS[1]] == y[PCM_KEYS[1]]
                status["native_pcm_equal_pairs"] += same_native and x["frames"] == y["frames"]
                status["pcm16_equal_pairs"] += same_pcm16 and x["frames"] == y["frames"]
                if left.startswith("kokoro") and right.startswith("kokoro") and (
                        not same_native or not same_pcm16 or x["frames"] != y["frames"]):
                    mismatches.append({"round": i, "id": fixture_id})
                if (left_done[i].get("play") and right_done[i].get("play")
                        and playback_complete(x) and playback_complete(y)):
                    status["complete_playback_pairs"] += 1
                    same_route = route(x) == route(y)
                    status["route_settings_matching_pairs"] += same_route
                    status["known_route_settings_matching_pairs"] += same_route and number(x.get("audio_route_type"), 1)
                    same_volume = pair_conditions(left_done[i], right_done[i], ("media_volume", "media_volume_max"))
                    status["volume_settings_matching_pairs"] += same_volume
                    status["positive_matched_volume_pairs"] += same_volume and number(left_done[i]["media_volume"], 1)
        status["kokoro_exact_verdict"] = (
            "FAIL" if mismatches else "PASS" if status["native_pcm_equal_pairs"] == rounds * len(ids) else "UNPROVEN"
        ) if left.startswith("kokoro") and right.startswith("kokoro") else "NOT_APPLICABLE"
        status["kokoro_mismatch_slots"] = mismatches
        metric_results = {}
        for key in PAIRED_METRICS:
            groups = [[(x[key], y[key]) for x, y in group.values() if number(x.get(key)) and number(y.get(key))]
                      for group in pairs]
            metric_results[key] = paired(groups, len(ids), rounds, resamples)
        result["buckets"][bucket] = {"checks": status, "metrics": metric_results}

    result["process_metrics"] = {
        key: paired([[(x[key], y[key])] if number(x.get(key)) and number(y.get(key)) else []
                     for x, y in zip(left_done, right_done)], 1, rounds, resamples) for key in ROUND_METRICS
    }
    result["condition_checks"] = {
        "same_thread_count_each_round": all(pair_conditions(x, y, ("threads",)) for x, y in zip(left_done, right_done)),
        "same_device_build_each_round": all(pair_conditions(x.get("conditions_start", {}), y.get("conditions_start", {}),
                                               ("model", "soc", "android", "fingerprint"))
                                               for x, y in zip(left_done, right_done)),
        "same_start_power_conditions_each_round": all(pair_conditions(x.get("conditions_start", {}), y.get("conditions_start", {}),
                                                         ("power_save", "battery_plugged"))
                                                         for x, y in zip(left_done, right_done)),
        "same_start_thermal_status_each_round": all(pair_conditions(x.get("conditions_start", {}), y.get("conditions_start", {}),
                                                       ("thermal_status",))
                                                       for x, y in zip(left_done, right_done)),
        "start_battery_temperature_c_candidate_minus_baseline": [
            (y["conditions_start"]["battery_temperature_tenths_c"] - x["conditions_start"]["battery_temperature_tenths_c"]) / 10
            if all(number(d.get("conditions_start", {}).get("battery_temperature_tenths_c")) for d in (x, y)) else None
            for x, y in zip(left_done, right_done)],
    }
    return result


def audit_schedule(results, summaries, rounds, issues):
    expected = [f"{list(ARMS)[arm]}/round-{i}" for i in range(rounds) for arm in ORDER[i % len(ORDER)]]
    try:
        schedule = read(results / "schedule.json")
        if not isinstance(schedule, list) or not all(isinstance(entry.get("label"), str) for entry in schedule):
            raise ValueError
        actual = [entry["label"] for entry in schedule]
    except (OSError, ValueError, TypeError, AttributeError):
        issues.append({"issue": "missing_or_invalid_schedule.json"})
        actual, schedule = [], []
    process_ids = [done["pid"] for records in summaries.values() for done in records if number(done.get("pid"), 1)]
    matched = 0
    for entry in schedule:
        for arm in ARMS:
            for done in summaries[arm]:
                if done.get("label") == entry["label"] and pair_conditions(done, entry, ("pid", "status")):
                    matched += 1
    return {"expected_order": expected, "observed_order": [label for label in actual if label in expected],
            "balanced_registered_order": actual == expected,
            "fresh_distinct_worker_pids": len(process_ids) == len(set(process_ids)) == len(expected),
            "schedule_matches_status_and_pid_count": matched,
            "unexpected_labels_count": sum(label not in expected for label in actual)}


def screen_summary(results):
    history = []
    for path in sorted((results / "screen").glob("*/done.json")):
        try:
            done = read(path)
            status = done.get("status") if done.get("status") in {"OK", "ERROR", "PARTIAL"} else "INVALID"
        except (OSError, ValueError, AttributeError, TypeError):
            status = "INVALID"
        if re.fullmatch(r"(?:kokoro|pico)-[0-9]+", path.parent.name):
            history.append({"config": path.parent.name, "status": status})
    selections = {}
    for engine in ("kokoro", "pico"):
        try:
            selection = read(results / f"{engine}-selection.json")
            observations = [{key: row.get(key) for key in ("threads", "eligible_exact_pcm", "median_first_signal_ready_ratio")}
                            for row in selection.get("observations", [])]
            selections[engine] = {**{key: selection.get(key) for key in ("screen_reference_threads", "selected_threads")},
                                  "observations": observations}
        except (OSError, ValueError, AttributeError):
            selections[engine] = None
    return {"attempts": history, "selected": selections}


def capture_identity(results):
    try:
        start, end = (read(results / f"device-{when}.json") for when in ("start", "end"))
    except (OSError, ValueError):
        return None
    if not isinstance(start, dict) or not isinstance(end, dict):
        return None
    return {"model_matches_base_s25": re.fullmatch(r"SM-S931[A-Z0-9]*", start.get("model", "")) is not None,
            "arm64_primary_abi": start.get("abis", "").startswith("arm64-v8a"),
            "start_end_device_build_match": pair_conditions(start, end, ("model", "soc", "android", "fingerprint")),
            "start": {key: start[key] for key in CONDITION_KEYS if key in start},
            "end": {key: end[key] for key in CONDITION_KEYS if key in end}}


def summarize(results, fixtures, rounds, resamples, synthetic=False):
    buckets = {kind: [key for key, row in fixtures.items() if row["bucket"] == kind]
               for kind in dict.fromkeys(row["bucket"] for row in fixtures.values())}
    buckets = {"overall": list(fixtures), **buckets}
    data, summaries, arm_results, issues = {}, {}, {}, []
    for arm in ARMS:
        runs = [member_data(arm, i, results / arm / f"round-{i}", fixtures, issues) for i in range(rounds)]
        done, samples, clocks = zip(*runs)
        summaries[arm] = done
        data[arm] = samples
        arm_results[arm] = {
            "process_metrics": distribution(done, ROUND_METRICS),
            "cold_first_request_compute": distribution([row.get("first_request_compute") or {} for row in done], REQUEST_METRICS),
            "round_status_counts": dict(Counter(row.get("status", "UNKNOWN") for row in done)),
            "successful_synthesis_requests": sum(len(rows) for rows in samples),
            "expected_synthesis_requests": rounds * len(fixtures),
            "playback_requested_rounds": sum(row.get("play") is True for row in done),
            "first_presented_timestamp_exclusions": dict(sum(clocks, Counter())),
            "repeat_audio_checks": repeat_audio(samples, fixtures),
            "selected_thread_values": sorted({row["threads"] for row in done if number(row.get("threads"), 1)}),
            "runtime_labels": sorted({row["runtime"] for row in done if isinstance(row.get("runtime"), str)}),
            "conditions_start": condition_view(done, "conditions_start"),
            "conditions_end": condition_view(done, "conditions_end"),
            "request_thermal_status": stats(row.get("thermal_status") for group in samples for row in group.values()),
            "audio_environment": audio_checks(samples, done),
            "buckets": {bucket: distribution([row for group in samples for key, row in group.items() if key in ids],
                                             REQUEST_METRICS) for bucket, ids in buckets.items()},
        }
    schedule = audit_schedule(results, summaries, rounds, issues)
    schedule["same_fixture_order_each_round"] = all(
        len({tuple(data[arm][i]) for arm in ARMS}) == 1
        and len(data[next(iter(ARMS))][i]) == len(fixtures)
        for i in range(rounds)
    )
    screen = screen_summary(results)
    schedule["final_threads_match_screen_selection"] = all(
        (screen["selected"].get(engine) or {}).get("selected_threads") == done.get("threads")
        and number(done.get("threads"), 1)
        for arm, (engine, _) in ARMS.items() for done in summaries[arm]
    )
    return {
        "provenance": "synthetic verification, no measured results" if synthetic else "external Android capture analysis",
        "capture_identity": capture_identity(results),
        "rounds_requested": rounds, "fixtures_by_bucket": buckets,
        "statistics": {"ci": "paired percentile bootstrap of complete whole rounds, with fixed fixture sets",
                       "confidence": 0.95, "resamples": resamples, "seed": SEED,
                       "quantile": "linear interpolation between sorted observations",
                       "notes": ["Incomplete rounds contribute to available paired point estimates only.",
                                 "Intervals have a separate point estimate over complete paired rounds.",
                                 "Intervals require at least three complete paired rounds.",
                                 "Pairwise ratios use candidate divided by baseline; lower is better for latency and RAM."]},
        "metric_limits": {
            "first_presented_signal_ms": "Android AudioTrack estimated presentation of a signal threshold crossing, without microphone confirmation. A muted or unknown route limits claims about audible output.",
            "synthesis_complete_ms": "In-app request through generation completion including frontend, callbacks and PCM conversion, excluding playback drain.",
            "presentation_to_drain_ms": "Derived from playback drain minus estimated first presentation. Compare along with PCM duration and underrun counts.",
            "rtf": "Synthesis wall time divided by output duration. Speech duration may differ across models.",
            "pss": "Sampled process PSS, not continuous peak PSS.",
            "vm_hwm_kib": "Cumulative worker-process RSS high-water mark; not reset between requests.",
            "load_ms": "Fresh-process engine creation, with possible operating-system file cache reuse.",
        },
        "arm_summaries": arm_results, "schedule": schedule, "thread_screen": screen,
        "controller_failure_recorded": (results / "error.txt").is_file(),
        "issues": sorted(issues, key=lambda item: (item.get("arm", ""), item.get("round", -1), item.get("id") or "", item["issue"])),
        "comparisons": [compare(left, right, data[left], data[right], summaries, buckets, rounds, resamples)
                        for left, right in PAIRS],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, required=True, help="extracted directory holding the arm directories")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--fixtures", type=Path, default=Path(__file__).resolve().parents[1] / "fixtures/requests.jsonl")
    parser.add_argument("--rounds", type=int, default=6)
    parser.add_argument("--resamples", type=int, default=5000)
    parser.add_argument("--synthetic", action="store_true", help="label generated verification data as synthetic")
    args = parser.parse_args()
    if args.rounds < 1 or args.resamples < 1 or not args.results.is_dir():
        parser.error("positive rounds and resamples and an existing results directory are required")
    fixture_rows = read(args.fixtures, lines=True)
    fixtures = {row["id"]: row for row in fixture_rows}
    if not fixtures or len(fixtures) != len(fixture_rows):
        parser.error("expected a nonempty fixture list with unique IDs")
    result = summarize(args.results, fixtures, args.rounds, args.resamples, args.synthetic)
    result["fixture_sha256"] = hashlib.sha256(args.fixtures.read_bytes()).hexdigest()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
