# Galaxy S25 published Kokoro configurations

In every experiment (quantisation, precision, activation bit-width, kernel or graph change, approximation, any optimisation), measure the speed of every variant even when its quality fails or is broken. Never skip, defer or drop a timing because quality broke. Record quality and speed side by side, and label a broken-quality row as such, but still time it. If a timing truly cannot run (the build is refused, or it crashes), report it as NOT RUN with the exact error, never "skipped because of quality". Pass this rule verbatim into every subagent and workflow brief.

- Reuse the four registered English prompts and exact three sentence boundaries from the precision matrix. Test one warm request through Android playback drain on the base Galaxy S25. Reuse the AudioTrack buffer and the same rules for detecting speech and waiting between chunks.
- Test the published Sherpa-ONNX Kokoro INT8 v1.0 export on Sherpa 1.13.6 CPU (two threads), the MediaPipe Tasks Audio 1.2.2 LiteRT community INT8 model with its OpenCL vocoder, the independent Adreno-LLMs FP16 weights and FP32 generator profile, and native Pico INT8 on two CPU threads. Record effective GPU placement, weight hashes and engine versions. The Kokoro checkpoints receive their documented af_heart presets. Pico uses Eleanor and keeps the CPU matrix's first-pause behavior.
- Use four balanced fresh-process rounds with all arms, preserving identical fixture order within each round. Report first PCM and first speech separately, plus synthesis time, RTF, audio duration per chunk and digital playback misses. Use retained renders for descriptive audio quality checks.
- Interpret the comparison as deployed engine configurations under the same input and timing contract. Report unsupported or failed cells with the actual runtime message.

[Fixtures](../fixtures/matched-chunks.jsonl) · [Checkpoint hashes](../../evidence/published-panel/checkpoints.json) · [APK source](../source/)
