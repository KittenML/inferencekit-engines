# Galaxy S25 benchmark archive

Includes the selected package's recorded request timings, registered plans,
quality outputs, and study reproduction sources. Older study paths are
relative to the archive root. Some notes describe optional experiments with
additional toolchains and checkpoint downloads.

Host paths and device identifiers were redacted. Raw provider job records,
phone dumps, and bulky service logs are omitted. Formats, fixtures, and
observed timing values are preserved. SHA256SUMS covers the sanitized files.
Executable build artifacts, model weights and audio recordings are absent.
Shared study diagnostics and VieNeu measurements were omitted. The Kokoro timing traces remain in their original groups.
