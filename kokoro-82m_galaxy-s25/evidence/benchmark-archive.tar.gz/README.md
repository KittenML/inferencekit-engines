# Kokoro-82M on Galaxy S25

On-device English sentence streaming with the MediaPipe LiteRT vocoder on Adreno OpenCL. An independent Adreno FP16 configuration and a Sherpa-ONNX CPU benchmark are included.

## Requirements

Galaxy S25 with USB debugging. Build on Linux x86-64 with JDK 17, Android SDK 35, Build Tools 35.0.0, platform-tools, Python 3.11+, curl and unzip. Set `ANDROID_SDK_ROOT`. Allow 8 GB of host disk space. The optional comparison builds also use NDK r27d, CMake, Ninja and Rust.

## Run

```bash
./install.sh
./serve.sh
./test.sh
```

The smoke test saves a WAV under `build/output/`. Run `./bench.sh kokoro-sustained` to repeat the capacity workload on an attached device.

## Results

MediaPipe INT8 sustained **three simultaneous streams for 7.5 minutes** with simulated playback. In the separate single-request AudioTrack test it finished synthesis in **2.18 s p95** with zero underruns. The standalone Adreno build also sustained three streams. Both failed the tested four-stream load. [Timings, baselines and audio checks](REPORT.md)

## How it was made

Codex used InferenceKit to expose Adreno OpenCL to MediaPipe, adapt the independent FP16 runner for timed sentence callbacks, and check frame identity across GPU scheduling experiments. A separate Sherpa harness pipelined synthesis with Android playback. [Implementation and outcomes](REPORT.md#details)

## Limits

Capacity uses simulated playback. The FP32 CPU startup experiment measures Android presentation and incurs underruns on the longer prompts. Cross-runtime perceptual equivalence is unproven.

## License

Apache-2.0. Downloaded models and upstream runtimes use their own licenses. [Pinned sources](REPORT.md#files-and-outputs)
