# Single-request benchmark archive

Run the timing reducer on the capture directory. PCM audio is omitted.
